/*
 * receiver_tasks.h
 *
 * Created: 3/4/2021 5:06:41 PM
 *  Author: mattp
 */ 


#ifndef RECEIVER_TASKS_H_
#define RECEIVER_TASKS_H_

void process_command_task(void *command);



#endif /* RECEIVER_TASKS_H_ */