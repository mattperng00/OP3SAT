#include <atmel_start.h>
#include "send_transmit.h"
#include <stdio.h>

void t1(void *pvParameters);
void t2(void *pvParameters);

QueueHandle_t q1;

int main(void)
{
	
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	//init async driver
	async_setup();
	
    q1 = xQueueCreate((UBaseType_t) 1, (UBaseType_t) sizeof(int));
	
	BaseType_t rc;
	rc = xTaskCreate(t1, "t1", 256, &q1, 2, NULL);
	rc = xTaskCreate(t2, "t2", 256, &q1, 2, NULL);
	
	vTaskStartScheduler();
	/* Replace with your application code */
	while (1) {
		//check for receiving
		//transmit();
		//Global_Queue
		//receive_callback();
	}
}

void t1(void *pvParameters)
{
	int integer = 0;
	QueueHandle_t output = *(QueueHandle_t*)pvParameters;
	
	for (;;)
	{
		xQueueSend(output, &integer, portMAX_DELAY);
		integer++;
		delay_ms(1000);
	}
}

void t2(void *pvParameters)
{
	QueueHandle_t input = *(QueueHandle_t*)pvParameters;
	bool led = true;
	int n;
	
	for (;;)
	{
		xQueueReceive(input, &n, portMAX_DELAY);
		gpio_set_pin_level(BLINK, led);
		
		led = !led;
		//delay_ms(1000);
		//gpio_set_pin_level(BLINK,false);
		//delay_ms(1000);
	}
}